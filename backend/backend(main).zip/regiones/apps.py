from django.apps import AppConfig


class RegionesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'regiones'
