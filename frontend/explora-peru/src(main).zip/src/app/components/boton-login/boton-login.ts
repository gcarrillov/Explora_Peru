import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-boton-login',
  standalone: true,
  templateUrl: './boton-login.html',
  styleUrls: ['./boton-login.css'],
  encapsulation: ViewEncapsulation.None
})
export class BotonLoginComponent {}
