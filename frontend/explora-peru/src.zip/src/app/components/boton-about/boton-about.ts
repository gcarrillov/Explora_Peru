import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-boton-about',
  standalone: true,
  templateUrl: './boton-about.html',
  styleUrls: ['./boton-about.css'],
  encapsulation: ViewEncapsulation.None
})
export class BotonAboutComponent {}
