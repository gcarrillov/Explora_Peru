import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-boton-aleatorio',
  standalone: true,
  templateUrl: './boton-aleatorio.html',
  styleUrls: ['./boton-aleatorio.css'],
  encapsulation: ViewEncapsulation.None
})
export class BotonAleatorioComponent {}
